package com.hibernateproject.hibernate_project_demo;

import org.hibernate.cfg.Configuration;

import java.util.*;
import com.hibernateproject.hibernate_project_demo.model.Address;
import com.hibernateproject.hibernate_project_demo.model.AnudipEmployee;
import com.hibernateproject.hibernate_project_demo.model.AnudipEnrollment;
import com.hibernateproject.hibernate_project_demo.model.AnudipStudent;
import com.hibernateproject.hibernate_project_demo.model.Student;

import jakarta.persistence.Query;

import com.hibernateproject.hibernate_project_demo.model.Question1;
import com.hibernateproject.hibernate_project_demo.model.Answer1;

import org.hibernate.SessionFactory;
import org.hibernate.Session;
import org.hibernate.Transaction;
/**
 * Hello world!
 */
public class App {
    public static void main(String[] args) {
    	//Option 1
       SessionFactory sf=new Configuration().configure().buildSessionFactory();//pipelining 
       //Option 2
      // Configuration cfg=new Configuration();
      // SessionFactory sf1=cfg.configure().buildSessionFactory();
       Session session=sf.openSession();
       
       
//       Student student=new Student();
//       student.setStudentName("Nisha");
//       student.setStudentAge(28);
       
//       Address address=new Address("Street1","New Delhi","India","110058");
//       
//       AnudipEmployee ae=new AnudipEmployee("Rahul",address);//object as a reference/parameter
//       
       
//       Answer1 ans=new Answer1("Java is OOPLanguage");
//       
//       Question1 ques=new Question1("What is Java?",ans);
       
       AnudipEnrollment ae1=new AnudipEnrollment("AJP","ANP-3117");
       AnudipEnrollment ae2=new AnudipEnrollment("AJPNFS","ANP-3117");
       AnudipEnrollment ae3=new AnudipEnrollment("FWP","ANP-3117");
       
       List<AnudipEnrollment> list=new ArrayList<>();
       list.add(ae1);
       list.add(ae2);
       list.add(ae3);
       AnudipStudent as=new AnudipStudent("Nikita","AF2354",list);
       Transaction t=session.beginTransaction();
       session.persist(as);//first level cache
       t.commit();
       session.close();
       System.out.println("Data inserted successfully!!");
       
       
       
    }
    void codeForSelect()
    {
        	       
//    	       Student student=new Student();
//    	       student.setStudentName("Nisha");
//    	       student.setStudentAge(28);
    	       
//    	       Address address=new Address("Street1","New Delhi","India","110058");
//    	       
//    	       AnudipEmployee ae=new AnudipEmployee("Rahul",address);//object as a reference/parameter
//    	       
    	       
//    	       Answer1 ans=new Answer1("Java is OOPLanguage");
//    	       
//    	       Question1 ques=new Question1("What is Java?",ans);
    	       
//    	       AnudipEnrollment ae1=new AnudipEnrollment("AJP","ANP-3117");
//    	       AnudipEnrollment ae2=new AnudipEnrollment("AJPNFS","ANP-3117");
//    	       AnudipEnrollment ae3=new AnudipEnrollment("FWP","ANP-3117");
//    	       
//    	       List<AnudipEnrollment> list=new ArrayList<>();
//    	       list.add(ae1);
//    	       list.add(ae2);
//    	       list.add(ae3);
//    	       AnudipStudent as=new AnudipStudent("Nikita","AF2354",list);
    	    	 SessionFactory sf=new Configuration().configure().buildSessionFactory();//pipelining 
    	          //Option 2
    	         // Configuration cfg=new Configuration();
    	         // SessionFactory sf1=cfg.configure().buildSessionFactory();
    	          Session session=sf.openSession();
    	        
    	    	
    	    	Transaction t=session.beginTransaction();
    	    	String query="FROM Student";
    	    	Query q=session.createQuery(query);
    	    	List<Student> listStudent=q.getResultList();
    	    	
    	    	for(Student s: listStudent)
    	    	{
    	    		System.out.println(s.getStudentId()+" "+s.getStudentName()+" "+s.getStudentAge());
    	    	}
    	       t.commit();
    	       session.close();
    	       sf.close();
    	       System.out.println("Data inserted successfully!!");
    	       
    	       
    	       
    
    }
}
