package com.hibernateproject.hibernate_project_demo.model;

import jakarta.persistence.*;

@Entity
@Table(name="anudip_enrollment")
public class AnudipEnrollment {

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="e_id")
	int eId;
	
	@ManyToOne
	@JoinColumn(name="id")
	private AnudipStudent id;//name of the foreign key column
	
	@Column(length = 10)
	private String courseId;
	
	@Column(length = 10)
	private String InstructorId;

	public AnudipEnrollment(String courseId, String instructorId) {
		super();
		this.courseId = courseId;
		InstructorId = instructorId;
	}

	public int geteId() {
		return eId;
	}

	public void seteId(int eId) {
		this.eId = eId;
	}

	public AnudipStudent getId() {
		return id;
	}

	public void setId(AnudipStudent id) {
		this.id = id;
	}

	public String getCourseId() {
		return courseId;
	}

	public void setCourseId(String courseId) {
		this.courseId = courseId;
	}

	public String getInstructorId() {
		return InstructorId;
	}

	public void setInstructorId(String instructorId) {
		InstructorId = instructorId;
	}

	public AnudipEnrollment() {
		super();
	}
	
	
}
