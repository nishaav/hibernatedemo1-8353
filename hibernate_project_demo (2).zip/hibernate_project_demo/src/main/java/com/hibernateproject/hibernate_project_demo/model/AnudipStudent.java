package com.hibernateproject.hibernate_project_demo.model;

import jakarta.persistence.*;
import java.util.*;

@Entity
@Table(name="anudip_student")
public class AnudipStudent 
{
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="id")
	int id;
	
	@Column(name="name", length=100)
	String name;
	
	@Column(name="student_code",length=20)
	String studentCode;
	
	@OneToMany(mappedBy="id",cascade = CascadeType.ALL)
	List<AnudipEnrollment> list;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getStudentCode() {
		return studentCode;
	}

	public void setStudentCode(String studentCode) {
		this.studentCode = studentCode;
	}

	public List<AnudipEnrollment> getList() {
		return list;
	}

	public void setList(List<AnudipEnrollment> list) {
		this.list = list;
	}

	public AnudipStudent( String name, String studentCode, List<AnudipEnrollment> list) {
		super();
		
		this.name = name;
		this.studentCode = studentCode;
		this.list = list;
	}
	
	public AnudipStudent()
	{
		
	}
	
}
