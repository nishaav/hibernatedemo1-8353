package com.hibernateproject.hibernate_project_demo;
import org.hibernate.*;
import com.hibernateproject.hibernate_project_demo.model.*;

public class Fetch {
	
	public static void main(String args[])
	{
		SessionFactory sf=HibernateUtil.getSessionFactory();
		
		Session session=sf.openSession();
		
		Transaction t=session.beginTransaction();
		Student student=session.get(Student.class, 5);//select * from student where student_id=1;
		if(student.getStudentId()>0)
		{
			System.out.println("Data Received");
		}
		else
		{
			System.out.println("Not Received");
		}
		System.out.println(student.getStudentId()+" "+student.getStudentName()+" "+student.getStudentAge());
		
		t.commit();
		session.close();
		
		sf.close();
	}
}
