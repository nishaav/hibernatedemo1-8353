package com.hibernateproject.hibernate_project_demo.model;

import jakarta.persistence.*;
@Entity
@Table(name="answer1")
public class Answer1 {

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int id;
	
	@Column(name="answer",length=80)
	private String answer;

	public Answer1(String answer) {
		super();
		this.answer = answer;
	}
	
public Answer1() {
		
	}

	

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getAnswer() {
		return answer;
	}

	public void setAnswer(String answer) {
		this.answer = answer;
	}
	
	
}
