package com.hibernateproject.hibernate_project_demo.model;

import jakarta.persistence.*;

@Entity
@Table(name = "question1")
public class Question1 {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "q_id")
	private int quesId;

	@Column(name = "question", nullable = false, length = 100)
	private String question;

	@OneToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "id")//unidirectional // bidirectional
	private Answer1 answer;

	// Question----Answer
	public Question1(String question, Answer1 answer) {
		super();

		this.question = question;
		this.answer = answer;
	}

	public Question1() {
		super();
	}

	public int getQuesId() {
		return quesId;
	}

	public void setQuesId(int quesId) {
		this.quesId = quesId;
	}

	public String getQuestion() {
		return question;
	}

	public void setQuestion(String question) {
		this.question = question;
	}

	public Answer1 getAnswer() {
		return answer;
	}

	public void setAnswer(Answer1 answer) {
		this.answer = answer;
	}

}
