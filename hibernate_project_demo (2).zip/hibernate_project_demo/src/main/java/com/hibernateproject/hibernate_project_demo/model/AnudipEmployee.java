package com.hibernateproject.hibernate_project_demo.model;

import jakarta.persistence.Entity;
import jakarta.persistence.Table;
import jakarta.persistence.*;
@Entity
@Table(name="anudip_employee")
public class AnudipEmployee {
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="emp_id")
	private int empId;
	
	@Column(name="emp_name", nullable=false, length=20)
	private String empName;
	
	@Embedded
//	@AttributeOverrides({
//		@AttributeOverride(name="street",column=@Column(name="landmark")),
//		@AttributeOverride(name="zip",column=@Column(name="pincode"))
//	})
	private Address address;

	public AnudipEmployee()
	{
		
	}
	
	public AnudipEmployee(String empName, Address address) {
		super();
		this.empName = empName;
		this.address = address;
	}

	public int getEmpId() {
		return empId;
	}

	public void setEmpId(int empId) {
		this.empId = empId;
	}

	public String getEmpName() {
		return empName;
	}

	public void setEmpName(String empName) {
		this.empName = empName;
	}

	public Address getAddress() {
		return address;
	}

	public void setAddress(Address address) {
		this.address = address;
	}
	

}
