package com.hibernateproject.hibernate_project_demo;

import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
public class HibernateUtil {

	// Singleton Object : Singleton Design Pattern
	private static SessionFactory sessionFactory=buildSessionFactory();

	private static SessionFactory buildSessionFactory() {
		// TODO Auto-generated method stub
		SessionFactory sf=new Configuration().configure().buildSessionFactory();//pipelining 
	       return sf;
	}
	
	public static SessionFactory getSessionFactory()
	{
		return sessionFactory;
	}
}
