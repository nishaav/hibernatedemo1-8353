package com.hibernateproject.hibernate_project_demo;

import org.hibernate.cfg.Configuration;

import com.hibernateproject.hibernate_project_demo.model.Student;

import org.hibernate.SessionFactory;
import org.hibernate.Session;
import org.hibernate.Transaction;
/**
 * Hello world!
 */
public class App {
    public static void main(String[] args) {
    	//Option 1
       SessionFactory sf=new Configuration().configure().buildSessionFactory();//pipelining 
       //Option 2
      // Configuration cfg=new Configuration();
      // SessionFactory sf1=cfg.configure().buildSessionFactory();
       Session session=sf.openSession();
       Student student=new Student();
       student.setStudentName("Nisha");
       student.setStudentAge(28);
       Transaction t=session.beginTransaction();
       session.persist(student);//first level cache
       t.commit();
       session.close();
       System.out.println("Data inserted successfully!!");
       
       
       
    }
}
